package com.example.studynotes.ui.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import com.example.studynotes.R;
import com.example.studynotes.model.Note;
import com.example.studynotes.service.NoteInfo;

import java.util.List;

public class NotesAdapter extends RecyclerView.Adapter<NotesAdapter.NotesViewHolder> {
    private final Context context;
    private List<Note> notesList;

    // Constructor to initialize the adapter with the context and list of notes
    public NotesAdapter(Context context, List<Note> notesList) {
        this.context = context;
        this.notesList = notesList;
    }

    // Method to update the data and notify the adapter when the dataset changes
    public void changeData(List<Note> newFilterList) {
        notesList = newFilterList;
        notifyDataSetChanged();
    }

    // ViewHolder class representing individual items in the RecyclerView
    public static class NotesViewHolder extends RecyclerView.ViewHolder {
        private View viewPriority;
        private ImageView ivShare;
        private TextView notesTitle, notesSubtitle, notesDate;

        // Constructor to initialize views in the ViewHolder
        public NotesViewHolder(View itemView) {
            super(itemView);

            viewPriority = itemView.findViewById(R.id.viewPriority);
            ivShare = itemView.findViewById(R.id.ivShare);
            notesTitle = itemView.findViewById(R.id.notesTitle);
            notesSubtitle = itemView.findViewById(R.id.notesSubtitle);
            notesDate = itemView.findViewById(R.id.notesDate);
        }
    }

    // Method to create a new ViewHolder
    @Override
    public NotesViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_note, parent, false);

        return new NotesViewHolder(itemView);
    }

    // Method to bind data to views in the ViewHolder
    @Override
    public void onBindViewHolder(NotesViewHolder holder, int position) {
        // Get the note at the specified position in the list
        Note note = notesList.get(position);

        // Bind note data to views in the ViewHolder
        holder.notesTitle.setText(note.getTitle());
        holder.notesSubtitle.setText(note.getSubtitle());
        holder.notesDate.setText(note.getDate());

        // Set the background color based on the note's priority
        switch (note.getPriority()) {
            case LOW:
                holder.viewPriority.setBackgroundResource(R.drawable.green_dot);
                break;
            case MEDIUM:
                holder.viewPriority.setBackgroundResource(R.drawable.yellow_dot);
                break;
            case HIGH:
                holder.viewPriority.setBackgroundResource(R.drawable.red_dot);
                break;
        }

        // Set OnClickListener for the entire note item to navigate to the EditNotesFragment
        holder.itemView.setOnClickListener(view -> {
            NoteInfo.setNote(note);
            Navigation.findNavController(view).navigate(R.id.action_homeFragment_to_editNotesFragment);
        });

        // Set OnClickListener for the share icon to share the content of the note
        holder.ivShare.setOnClickListener(view -> {
            String sharingMessage = "Note Title: " + note.getTitle() + "\n\n" +
                    "Note Subtitle: " + note.getSubtitle() + "\n" +
                    "Note Description: " + note.getDescription();

            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_TEXT, sharingMessage);
            view.getContext().startActivity(Intent.createChooser(intent, "Share via:"));
        });
    }

    // Method to get the total number of items in the RecyclerView
    @Override
    public int getItemCount() {
        return notesList.size();
    }
}

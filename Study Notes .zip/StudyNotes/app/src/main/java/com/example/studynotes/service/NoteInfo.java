package com.example.studynotes.service;

import com.example.studynotes.model.Note;

public class NoteInfo {
    private static Note _note = null;

    // Method to set the current Note
    public static void setNote(Note note) {
        _note = note;
    }

    // Method to retrieve the current Note
    public static Note getNote() {
        return _note;
    }

    // Method to remove the current Note
    public static void removeNote() {
        _note = null;
    }
}

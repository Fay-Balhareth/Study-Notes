package com.example.studynotes.repository;

import com.example.studynotes.db.NotesDatabaseHelper;
import com.example.studynotes.model.Note;

import java.util.List;

public class NotesRepository {
    private final NotesDatabaseHelper db;

    // Constructor to initialize the repository with a NotesDatabaseHelper instance
    public NotesRepository(NotesDatabaseHelper db) {
        this.db = db;
    }

    // Method to retrieve all notes from the database
    public List<Note> getAllNotes() {
        return db.getNotes();
    }

    // Method to retrieve high priority notes from the database
    public List<Note> getHighNotes() {
        return db.getNotes(Note.Priority.HIGH);
    }

    // Method to retrieve medium priority notes from the database
    public List<Note> getMediumNotes() {
        return db.getNotes(Note.Priority.MEDIUM);
    }

    // Method to retrieve low priority notes from the database
    public List<Note> getLowNotes() {
        return db.getNotes(Note.Priority.LOW);
    }

    // Method to add a note to the database
    public void insertNote(Note note) {
        db.addNote(note);
    }

    // Method to delete a note from the database by its ID
    public void deleteNote(int id) {
        db.deleteNote(id);
    }

    // Method to update a note in the database
    public void updateNote(Note note) {
        db.updateNote(note);
    }
}

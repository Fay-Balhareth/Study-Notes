package com.example.studynotes.ui.fragments;

import static com.example.studynotes.model.Note.Priority.LOW;

import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.example.studynotes.R;
import com.example.studynotes.model.Note;
import com.example.studynotes.service.NoteInfo;
import com.example.studynotes.viewmodel.NotesViewModel;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.Date;

public class EditNotesFragment extends Fragment {

    private Note note;
    private Note.Priority priority = LOW;
    private NotesViewModel viewModel;

    private View view;
    private ImageView pGreen, pYellow, pRed;
    private EditText edtTitle, edtSubtitle, edtDescription;
    private FloatingActionButton btnEditSaveNotes;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_edit_notes, container, false);
        setHasOptionsMenu(true);

        // Initialize UI components
        pGreen = view.findViewById(R.id.pGreen);
        pYellow = view.findViewById(R.id.pYellow);
        pRed = view.findViewById(R.id.pRed);
        edtTitle = view.findViewById(R.id.edtTitle);
        edtSubtitle = view.findViewById(R.id.edtSubtitle);
        edtDescription = view.findViewById(R.id.edtDescription);
        btnEditSaveNotes = view.findViewById(R.id.btnEditSaveNotes);

        // Retrieve the note data from NoteInfo
        note = NoteInfo.getNote();
        if (note != null) {
            // Populate UI components with existing note details
            edtTitle.setText(note.getTitle());
            edtSubtitle.setText(note.getSubtitle());
            edtDescription.setText(note.getDescription());

            // Set the initial priority based on the existing note's priority
            switch (note.getPriority()) {
                case LOW:
                    pGreen.setImageResource(R.drawable.ic_done);
                    pYellow.setImageResource(0);
                    pRed.setImageResource(0);
                    break;
                case MEDIUM:
                    pYellow.setImageResource(R.drawable.ic_done);
                    pGreen.setImageResource(0);
                    pRed.setImageResource(0);
                    break;
                case HIGH:
                    pRed.setImageResource(R.drawable.ic_done);
                    pGreen.setImageResource(0);
                    pYellow.setImageResource(0);
                    break;
            }

            // Set onClickListeners for priority indicators to allow users to choose the priority
            pGreen.setOnClickListener(v -> {
                priority = Note.Priority.LOW;
                pGreen.setImageResource(R.drawable.ic_done);
                pYellow.setImageResource(0);
                pRed.setImageResource(0);
            });

            pYellow.setOnClickListener(v -> {
                priority = Note.Priority.MEDIUM;
                pYellow.setImageResource(R.drawable.ic_done);
                pGreen.setImageResource(0);
                pRed.setImageResource(0);
            });

            pRed.setOnClickListener(v -> {
                priority = Note.Priority.HIGH;
                pRed.setImageResource(R.drawable.ic_done);
                pGreen.setImageResource(0);
                pYellow.setImageResource(0);
            });

            // Set onClickListener for the save button to update and save the note
            btnEditSaveNotes.setOnClickListener(this::updateNotes);
        } else {
            // Display a message and navigate to HomeFragment if note data is null
            Toast.makeText(requireContext(), "Data null!", Toast.LENGTH_SHORT).show();
            Navigation.findNavController(view).navigate(R.id.action_editNotesFragment_to_homeFragment);
        }

        // Initialize ViewModel for note-related operations
        viewModel = new ViewModelProvider(this).get(NotesViewModel.class);

        return view;
    }

    private void updateNotes(View view) {
        // Retrieve user input from text fields
        String title = edtTitle.getText().toString();
        String subtitle = edtSubtitle.getText().toString();
        String description = edtDescription.getText().toString();

        // Get the current date
        Date currentDate = new Date();
        CharSequence notesDate = DateFormat.format("MMMM d, yyyy ", currentDate.getTime());

        // Create a new Note object with the modified details
        Note note = new Note(
                this.note.getId(),
                title,
                subtitle,
                description,
                notesDate.toString(),
                priority
        );

        // Update the note in the ViewModel
        viewModel.updateNote(note);

        // Display a success message to the user
        Toast.makeText(requireContext(), "note updated successfully :)", Toast.LENGTH_LONG).show();

        // Remove the note data from NoteInfo
        NoteInfo.removeNote();

        // Navigate back to the HomeFragment
        Navigation.findNavController(view).navigate(R.id.action_editNotesFragment_to_homeFragment);
    }

    // Methods for handling options menu actions
    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.delete_menu, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            // Remove the note data from NoteInfo and navigate back to the HomeFragment
            NoteInfo.removeNote();

            Navigation.findNavController(view).navigate(R.id.action_editNotesFragment_to_homeFragment);
        } else if (item.getItemId() == R.id.menu_delete) {
            // Display a BottomSheetDialog for delete confirmation
            BottomSheetDialog bottomSheet = new BottomSheetDialog(requireContext(), R.style.BottomSheetStyle);
            bottomSheet.setContentView(R.layout.dialog_delete);

            TextView textViewYes = bottomSheet.findViewById(R.id.yes_dialog);
            TextView textViewNo = bottomSheet.findViewById(R.id.no_dialog);

            // Set onClickListeners for delete confirmation
            textViewYes.setOnClickListener(v -> {
                // Delete the note in the ViewModel and navigate back to the HomeFragment
                viewModel.deleteNote(note.getId());
                bottomSheet.dismiss();

                // Display a success message to the user
                Toast.makeText(requireContext(), "note deleted successfully :)", Toast.LENGTH_LONG).show();

                // Remove the note data from NoteInfo
                NoteInfo.removeNote();

                // Navigate back to the HomeFragment
                Navigation.findNavController(view).navigate(R.id.action_editNotesFragment_to_homeFragment);
            });

            textViewNo.setOnClickListener(v -> bottomSheet.dismiss());

            bottomSheet.show();
        }
        return super.onOptionsItemSelected(item);
    }
}

package com.example.studynotes.ui.fragments;

import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;
import com.example.studynotes.model.Note;
import com.example.studynotes.R;
import com.example.studynotes.service.NoteInfo;
import com.example.studynotes.viewmodel.NotesViewModel;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.Date;

public class CreateNotesFragment extends Fragment {
    private Note.Priority priority = Note.Priority.LOW;
    private NotesViewModel viewModel;

    private View view;
    private ImageView pGreen, pYellow, pRed;
    private EditText edtTitle, edtSubtitle, edtDescription;
    private FloatingActionButton btnSaveNotes;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_create_notes, container, false);

        // Initialize UI components
        pGreen = view.findViewById(R.id.pGreen);
        pYellow = view.findViewById(R.id.pYellow);
        pRed = view.findViewById(R.id.pRed);
        edtTitle = view.findViewById(R.id.edtTitle);
        edtSubtitle = view.findViewById(R.id.edtSubtitle);
        edtDescription = view.findViewById(R.id.edtDescription);
        btnSaveNotes = view.findViewById(R.id.btnSaveNotes);

        // Set the initial priority to LOW and color-code the priority indicators accordingly
        pGreen.setImageResource(R.drawable.ic_done);

        // Set onClickListeners for priority indicators to allow users to choose the priority
        pGreen.setOnClickListener(v -> {
            priority = Note.Priority.LOW;
            pGreen.setImageResource(R.drawable.ic_done);
            pYellow.setImageResource(0);
            pRed.setImageResource(0);
        });

        pYellow.setOnClickListener(v -> {
            priority = Note.Priority.MEDIUM;
            pYellow.setImageResource(R.drawable.ic_done);
            pGreen.setImageResource(0);
            pRed.setImageResource(0);
        });

        pRed.setOnClickListener(v -> {
            priority = Note.Priority.HIGH;
            pRed.setImageResource(R.drawable.ic_done);
            pGreen.setImageResource(0);
            pYellow.setImageResource(0);
        });

        // Set onClickListener for the save button to create and save the note
        btnSaveNotes.setOnClickListener(this::createNotes);

        // Initialize ViewModel for note-related operations
        viewModel = new ViewModelProvider(this).get(NotesViewModel.class);

        return view;
    }

    private void createNotes(View view) {
        // Retrieve user input from text fields
        String title = edtTitle.getText().toString();
        String subtitle = edtSubtitle.getText().toString();
        String description = edtDescription.getText().toString();

        // Get the current date
        Date currentDate = new Date();
        CharSequence notesDate = DateFormat.format("MMMM d, yyyy ", currentDate.getTime());

        // Create a new Note object with the specified details
        Note note = new Note(
                title,
                subtitle,
                description,
                notesDate.toString(),
                priority
        );

        // Add the created note to the list of notes in the ViewModel
        viewModel.addNote(note);

        // Display a success message to the user
        Toast.makeText(requireContext(), "note created successfully :)", Toast.LENGTH_LONG).show();

        // Navigate back to the HomeFragment
        Navigation.findNavController(view).navigate(R.id.action_createNotesFragment_to_homeFragment);
    }

    // Method for handling the up button press in the options menu
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            // Remove the note if the user navigates back without saving
            NoteInfo.removeNote();

            // Navigate back to the HomeFragment
            Navigation.findNavController(view).navigate(R.id.action_createNotesFragment_to_homeFragment);
        }
        return super.onOptionsItemSelected(item);
    }
}

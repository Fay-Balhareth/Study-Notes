package com.example.studynotes.ui.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.*;
import android.widget.SearchView;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import com.example.studynotes.SigninActivity;
import com.example.studynotes.model.Note;
import com.example.studynotes.R;
import com.example.studynotes.viewmodel.NotesViewModel;
import com.example.studynotes.ui.adapter.NotesAdapter;
import com.example.studynotes.viewmodel.UsersViewModel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {
    private NotesViewModel notesViewModel;
    private UsersViewModel usersViewModel;
    private ArrayList<Note> oldNotes = new ArrayList<>();
    private NotesAdapter adapter;

    private View view;
    private RecyclerView rvAllNotes;
    private View allNotes, filterHigh, filterMedium, filterLow;
    private FloatingActionButton btnAddNotes;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_home, container, false);
        setHasOptionsMenu(true);

        // Initialize UI components
        rvAllNotes = view.findViewById(R.id.rvAllNotes);
        allNotes = view.findViewById(R.id.allNotes);
        filterHigh = view.findViewById(R.id.filterHigh);
        filterMedium = view.findViewById(R.id.filterMedium);
        filterLow = view.findViewById(R.id.filterLow);
        btnAddNotes = view.findViewById(R.id.btnAddNotes);

        // Configure RecyclerView layout manager
        StaggeredGridLayoutManager staggeredGridLayoutManager = new StaggeredGridLayoutManager(2, LinearLayoutManager.VERTICAL);
        rvAllNotes.setLayoutManager(staggeredGridLayoutManager);

        // Initialize ViewModels for note and user-related operations
        notesViewModel = new ViewModelProvider(this).get(NotesViewModel.class);
        usersViewModel = new ViewModelProvider(this).get(UsersViewModel.class);

        // Display all notes on initial fragment creation
        getAllNotes();

        // Set onClickListeners for filter buttons and add notes button
        allNotes.setOnClickListener(v -> {
            getAllNotes();
        });

        filterHigh.setOnClickListener(v -> {
            getHighNotes();
        });

        filterMedium.setOnClickListener(v -> {
            getMediumNotes();
        });

        filterLow.setOnClickListener(v -> {
            getLowNotes();
        });

        btnAddNotes.setOnClickListener(v ->
                Navigation.findNavController(v).navigate(R.id.action_homeFragment_to_createNotesFragment)
        );

        return view;
    }

    // Method for retrieving all notes
    private void getAllNotes() {
        List<Note> notes = notesViewModel.getNotes();
        oldNotes = new ArrayList<>(notes);
        if (adapter == null) {
            adapter = new NotesAdapter(requireContext(), notes);
            rvAllNotes.setAdapter(adapter);
        } else {
            adapter.changeData(notes);
        }
    }

    // Method for retrieving high priority notes
    private void getHighNotes() {
        List<Note> notes = notesViewModel.getHighNotes();
        oldNotes = new ArrayList<>(notes);
        adapter.changeData(notes);
    }

    // Method for retrieving medium priority notes
    private void getMediumNotes() {
        List<Note> notes = notesViewModel.getMediumNotes();
        oldNotes = new ArrayList<>(notes);
        adapter.changeData(notes);
    }

    private void getLowNotes() {
        // Method for retrieving low priority notes
        List<Note> notes = notesViewModel.getLowNotes();
        oldNotes = new ArrayList<>(notes);
        adapter.changeData(notes);
    }

    // Method for handling options menu actions, exactly (search option)
    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.search_menu, menu);
        MenuItem item = menu.findItem(R.id.app_bar_search);
        SearchView searchView = (SearchView) item.getActionView();
        searchView.setQueryHint("Enter Notes Here...");

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                notesFilter(newText);
                return true;
            }
        });
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.app_bar_signout) {
            // Sign out and navigate to the sign-in activity
            usersViewModel.signout();

            startActivity(new Intent(getActivity(), SigninActivity.class));
            getActivity().finish();
        }
        return super.onOptionsItemSelected(item);
    }

    // Method for handling search functionality
    private void notesFilter(String newText) {
        ArrayList<Note> newFilterList = new ArrayList<>();
        for (Note note : oldNotes) {
            if (note.getTitle().contains(newText) || note.getSubtitle().contains(newText)) {
                newFilterList.add(note);
            }
        }
        adapter.changeData(newFilterList);
    }
}

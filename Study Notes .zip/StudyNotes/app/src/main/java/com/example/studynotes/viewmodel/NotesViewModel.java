package com.example.studynotes.viewmodel;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;

import com.example.studynotes.db.NotesDatabaseHelper;
import com.example.studynotes.model.Note;
import com.example.studynotes.repository.NotesRepository;

import java.util.List;

public class NotesViewModel extends AndroidViewModel {

    private NotesRepository repository;

    // Constructor to initialize the ViewModel with the application context
    public NotesViewModel(Application application) {
        super(application);

        // Initialize the repository with the application's database helper
        NotesDatabaseHelper db = new NotesDatabaseHelper(application);
        repository = new NotesRepository(db);
    }

    // Method to delegate adding a note to the repository
    public void addNote(Note note) {
        repository.insertNote(note);
    }

    // Method to delegate retrieving all notes to the repository
    public List<Note> getNotes() {
        return repository.getAllNotes();
    }

    // Method to delegate retrieving high priority notes to the repository
    public List<Note> getHighNotes() {
        return repository.getHighNotes();
    }

    // Method to delegate retrieving medium priority notes to the repository
    public List<Note> getMediumNotes() {
        return repository.getMediumNotes();
    }

    // Method to delegate retrieving low priority notes to the repository
    public List<Note> getLowNotes() {
        return repository.getLowNotes();
    }

    // Method to delegate deleting a note by its ID to the repository
    public void deleteNote(int id) {
        repository.deleteNote(id);
    }

    // Method to delegate updating a note to the repository
    public void updateNote(Note note) {
        repository.updateNote(note);
    }
}

package com.example.studynotes.viewmodel;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;

import com.example.studynotes.db.NotesDatabaseHelper;
import com.example.studynotes.model.User;
import com.example.studynotes.repository.UsersRepository;

public class UsersViewModel extends AndroidViewModel {

    private UsersRepository repository;

    // Constructor to initialize the ViewModel with the application context
    public UsersViewModel(Application application) {
        super(application);

        // Initialize the repository with the application's database helper
        NotesDatabaseHelper db = new NotesDatabaseHelper(application);
        repository = new UsersRepository(db);
    }

    // Method to delegate user signup operation to the repository
    public boolean signup(User user) {
        return repository.signup(user);
    }

    // Method to delegate user signin operation to the repository
    public boolean signin(User user) {
        return repository.signin(user);
    }

    // Method to delegate user signout operation to the repository
    public void signout() {
        repository.signout();
    }
}

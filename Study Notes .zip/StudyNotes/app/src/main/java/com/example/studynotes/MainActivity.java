package com.example.studynotes;

import static androidx.navigation.ui.NavigationUI.setupActionBarWithNavController;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

public class MainActivity extends AppCompatActivity {
    private NavController navController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize NavController and associate it with the specified navigation graph
        navController = Navigation.findNavController(this, R.id.fragmentContainerView);
        navController.setGraph(R.navigation.nav_graph);

        // Configure ActionBar to navigate up within the navigation hierarchy
        setupActionBarWithNavController(this, navController);
    }

    @Override
    public boolean onSupportNavigateUp() {
        // Navigate up within the navigation hierarchy or call the default behavior
        return navController.navigateUp() || super.onNavigateUp();
    }
}
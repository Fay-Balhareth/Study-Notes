package com.example.studynotes;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.example.studynotes.model.User;
import com.example.studynotes.viewmodel.UsersViewModel;

public class SigninActivity extends AppCompatActivity {
    private UsersViewModel viewModel;

    private EditText edtEmail, edtPassword;
    private Button btnSignin;
    private TextView tvSignup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin);

        // Initialize UI components
        edtEmail = findViewById(R.id.edtEmail);
        edtPassword = findViewById(R.id.edtPassword);
        btnSignin = findViewById(R.id.btnSignin);
        tvSignup = findViewById(R.id.tvSignup);

        // Initialize ViewModel for user-related operations
        viewModel = new ViewModelProvider(this).get(UsersViewModel.class);

        // Set onClickListener for the sign-in button
        btnSignin.setOnClickListener(view -> {
            // Retrieve user input
            String email = edtEmail.getText().toString().trim();
            String password = edtPassword.getText().toString().trim();

            // Validate email and password
            if (email.isEmpty()) {
                edtEmail.setError("empty email not valid!");
                edtEmail.requestFocus();
                return;
            }

            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                edtEmail.setError("email not valid!");
                edtEmail.requestFocus();
                return;
            }

            if (password.isEmpty()) {
                edtPassword.setError("empty password not valid!");
                edtPassword.requestFocus();
                return;
            }

            if (password.length() < 8) {
                edtPassword.setError("password less than 8 chars not valid!");
                edtPassword.requestFocus();
                return;
            }

            // Create a User object with the entered credentials
            User user = new User(email, password);

            // Perform sign-in and handle the result
            boolean result = viewModel.signin(user);

            if (result) {
                // Redirect to the main activity upon successful sign-in
                Toast.makeText(this, "sign in successfully :)", Toast.LENGTH_LONG).show();
                startActivity(new Intent(this, MainActivity.class));
                finish();
            } else {
                // Display an error message for unsuccessful sign-in
                Toast.makeText(this, "sign in unsuccessfully :(\nuser name or password not correct", Toast.LENGTH_LONG).show();
            }
        });

        // Set onClickListener for the sign-up text view
        tvSignup.setOnClickListener(view -> {
            startActivity(new Intent(this, SignupActivity.class));
            finish();
        });
    }
}
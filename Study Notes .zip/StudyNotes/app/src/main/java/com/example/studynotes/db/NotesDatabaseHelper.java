package com.example.studynotes.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.studynotes.model.Note;
import com.example.studynotes.model.User;
import com.example.studynotes.service.SignInInfo;

import java.util.ArrayList;
import java.util.List;

public class NotesDatabaseHelper extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "notes_db";
    private static final String TABLE_NOTES = "notes";

    private static final String KEY_ID = "id";
    private static final String KEY_TITLE = "title";
    private static final String KEY_SUBTITLE = "subtitle";
    private static final String KEY_DESCRIPTION = "description";
    private static final String KEY_DATE = "date";
    private static final String KEY_PRIORITY = "priority";


    private static final String TABLE_USERS = "users";

    private static final String KEY_USER_ID = "user_id";
    private static final String KEY_USER_EMAIL = "email";
    private static final String KEY_USER_PASSWORD = "password";

    public NotesDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_NOTES_TABLE = "CREATE TABLE " + TABLE_NOTES + "("
                + KEY_ID + " INTEGER PRIMARY KEY,"
                + KEY_TITLE + " TEXT,"
                + KEY_SUBTITLE + " TEXT,"
                + KEY_DESCRIPTION + " TEXT,"
                + KEY_DATE + " TEXT,"
                + KEY_PRIORITY + " INTEGER,"
                + KEY_USER_ID + " INTEGER"
                + ")";

        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + "("
                + KEY_USER_ID + " INTEGER PRIMARY KEY,"
                + KEY_USER_EMAIL + " TEXT,"
                + KEY_USER_PASSWORD + " TEXT"
                + ")";

        db.execSQL(CREATE_NOTES_TABLE);
        db.execSQL(CREATE_USERS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NOTES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    public boolean signUp(User user) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_USER_EMAIL, user.getEmail());
        values.put(KEY_USER_PASSWORD, user.getPassword());

        long result = db.insert(TABLE_USERS, null, values);
        db.close();

        return result > 0;
    }

    public int signin(User user) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_USERS,
                new String[]{KEY_USER_ID, KEY_USER_EMAIL, KEY_USER_PASSWORD},
                null, null, null, null, null, null);

        int userId = -1;

        if (cursor != null) {
            if (cursor.moveToFirst()) {
                do {
                    String email = cursor.getString(1);
                    String password = cursor.getString(2);

                    System.out.println("input: " + user.getEmail() + ", " + user.getPassword());
                    System.out.println("db: " + email + ", " + password);

                    if (email.equals(user.getEmail()) && password.equals(user.getPassword())) {
                        userId = cursor.getInt(0);
                        cursor.close();
                        break;
                    }
                } while (cursor.moveToNext());
            }
        }

        db.close();
        return userId;
    }


    public void addNote(Note note) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_TITLE, note.getTitle());
        values.put(KEY_SUBTITLE, note.getSubtitle());
        values.put(KEY_DESCRIPTION, note.getDescription());
        values.put(KEY_DATE, note.getDate());
        values.put(KEY_PRIORITY, note.getPriority().ordinal());
        values.put(KEY_USER_ID, SignInInfo.getUserId());

        db.insert(TABLE_NOTES, null, values);
        db.close();
    }

    public List<Note> getNotes() {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_NOTES,
                new String[]{
                        KEY_ID, KEY_TITLE, KEY_SUBTITLE, KEY_DESCRIPTION, KEY_DATE, KEY_PRIORITY, KEY_USER_ID
                },
                null, null, null, null, null);

        List<Note> notes = new ArrayList<>();

        if (cursor != null) {
            if (cursor.moveToFirst()) {
                do {
                    int userId = cursor.getInt(6);
                    if (userId == SignInInfo.getUserId()) {
                        Note note = new Note();

                        note.setId(cursor.getInt(0));
                        note.setTitle(cursor.getString(1));
                        note.setSubtitle(cursor.getString(2));
                        note.setDescription(cursor.getString(3));
                        note.setDate(cursor.getString(4));
                        note.setPriority(Note.Priority.values()[cursor.getInt(5)]);

                        notes.add(note);
                    }
                } while (cursor.moveToNext());
            }
        }

        db.close();
        return notes;
    }

    public List<Note> getNotes(Note.Priority priority) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_NOTES,
                new String[]{
                        KEY_ID, KEY_TITLE, KEY_SUBTITLE, KEY_DESCRIPTION, KEY_DATE, KEY_PRIORITY, KEY_USER_ID
                },
                KEY_PRIORITY + "=?",
                new String[]{String.valueOf(priority.ordinal())},
                null, null, null, null);

        List<Note> notes = new ArrayList<>();

        if (cursor != null) {
            if (cursor.moveToFirst()) {
                do {
                    int userId = cursor.getInt(6);
                    if (userId == SignInInfo.getUserId()) {
                        Note note = new Note();

                        note.setId(cursor.getInt(0));
                        note.setTitle(cursor.getString(1));
                        note.setSubtitle(cursor.getString(2));
                        note.setDescription(cursor.getString(3));
                        note.setDate(cursor.getString(4));
                        note.setPriority(Note.Priority.values()[cursor.getInt(5)]);

                        notes.add(note);
                    }
                } while (cursor.moveToNext());
            }
        }

        db.close();
        return notes;
    }

    public void deleteNote(int id) {
        SQLiteDatabase db = this.getWritableDatabase();

        String selection = KEY_ID + "=?";
        String[] selectionArgs = { String.valueOf(id) };

        // Delete the note based on its ID
        db.delete(TABLE_NOTES, selection, selectionArgs);

        // Close the database connection
        db.close();
    }

    public void updateNote(Note note) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_TITLE, note.getTitle());
        values.put(KEY_SUBTITLE, note.getSubtitle());
        values.put(KEY_DESCRIPTION, note.getDescription());
        values.put(KEY_DATE, note.getDate());
        values.put(KEY_PRIORITY, note.getPriority().ordinal());

        String selection = KEY_ID + "=?";
        String[] selectionArgs = { String.valueOf(note.getId()) };

        // Update the note based on its ID
        db.update(TABLE_NOTES, values, selection, selectionArgs);

        // Close the database connection
        db.close();
    }
}

package com.example.studynotes;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.studynotes.model.User;
import com.example.studynotes.viewmodel.UsersViewModel;

public class SignupActivity extends AppCompatActivity {
    private UsersViewModel viewModel;

    private EditText edtEmail, edtPassword, edtConfirmPassword;
    private Button btnSignup;
    private TextView tvSignin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        // Initialize UI components
        edtEmail = findViewById(R.id.edtEmail);
        edtPassword = findViewById(R.id.edtPassword);
        edtConfirmPassword = findViewById(R.id.edtConfirmPassword);
        btnSignup = findViewById(R.id.btnSignup);
        tvSignin = findViewById(R.id.tvSignin);

        // Initialize ViewModel for user-related operations
        viewModel = new ViewModelProvider(this).get(UsersViewModel.class);

        // Set onClickListener for the sign-up button
        btnSignup.setOnClickListener(view -> {
            // Retrieve user input
            String email = edtEmail.getText().toString().trim();
            String password = edtPassword.getText().toString().trim();
            String confirmPassword = edtConfirmPassword.getText().toString().trim();

            // Validate email, password, and confirm password
            if (email.isEmpty()) {
                edtEmail.setError("empty email not valid!");
                edtEmail.requestFocus();
                return;
            }

            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                edtEmail.setError("email not valid!");
                edtEmail.requestFocus();
                return;
            }

            if (password.isEmpty()) {
                edtPassword.setError("empty password not valid!");
                edtPassword.requestFocus();
                return;
            }

            if (password.length() < 8) {
                edtPassword.setError("password less than 8 chars not valid!");
                edtPassword.requestFocus();
                return;
            }

            if (confirmPassword.isEmpty()) {
                edtConfirmPassword.setError("empty confirm password not valid!");
                edtConfirmPassword.requestFocus();
                return;
            }

            if (!confirmPassword.equals(password)) {
                edtConfirmPassword.setError("confirm password doesn't equal password!");
                edtConfirmPassword.requestFocus();
                return;
            }

            // Create a User object with the entered credentials
            User user = new User(email, password);

            // Perform sign-up and handle the result
            boolean result = viewModel.signup(user);

            if (result) {
                // Redirect to the sign-in activity upon successful sign-up
                Toast.makeText(this, "sign up successfully :)", Toast.LENGTH_LONG).show();
                startActivity(new Intent(this, SigninActivity.class));
                finish();
            } else {
                // Display an error message for unsuccessful sign-up
                Toast.makeText(this, "sign up unsuccessfully :(", Toast.LENGTH_LONG).show();
            }
        });

        // Set onClickListener for the sign-in text view
        tvSignin.setOnClickListener(view -> {
            // Redirect to the sign-in activity
            startActivity(new Intent(this, SigninActivity.class));
            finish();
        });
    }
}
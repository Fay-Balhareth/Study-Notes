package com.example.studynotes.service;

public class SignInInfo {
    private static int id = -1;

    // Method to update the user ID after signin
    public static void signin(int userId) {
        id = userId;
    }

    // Method to retrieve the user ID
    public static int getUserId() {
        return id;
    }

    // Method to sign out by resetting the user ID
    public static void signout() {
        id = -1;
    }
}

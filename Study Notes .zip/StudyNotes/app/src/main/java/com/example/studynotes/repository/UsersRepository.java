package com.example.studynotes.repository;

import com.example.studynotes.db.NotesDatabaseHelper;
import com.example.studynotes.model.Note;
import com.example.studynotes.model.User;
import com.example.studynotes.service.SignInInfo;

import java.util.List;

public class UsersRepository {
    private final NotesDatabaseHelper db;

    // Constructor to initialize the repository with a NotesDatabaseHelper instance
    public UsersRepository(NotesDatabaseHelper db) {
        this.db = db;
    }

    // Method to delegate user signup operation to the database helper
    public boolean signup(User user) {
        return db.signUp(user);
    }

    // Method to delegate user signin operation to the database helper, updating SignInInfo with the signin result
    public boolean signin(User user) {
        int result = db.signin(user);
        SignInInfo.signin(result);
        return result != -1;
    }

    // Method to delegate user signout operation to SignInInfo
    public void signout() {
        SignInInfo.signout();
    }
}

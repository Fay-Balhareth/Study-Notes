package com.example.studynotes.model;

public class Note {
    private int id;
    private String title;
    private String subtitle;
    private String description;
    private String date;
    private Priority priority;

    // Default constructor
    public Note() {}

    // Constructor for creating an instance without an 'id'
    public Note(String title, String subtitle, String description, String date, Priority priority) {
        this.title = title;
        this.subtitle = subtitle;
        this.description = description;
        this.date = date;
        this.priority = priority;
    }

    // Constructor for creating an instance with an 'id'
    public Note(int id, String title, String subtitle, String description, String date, Priority priority) {
        this(title, subtitle, description, date, priority);
        this.id = id;
    }


    public void setId(int id) {
        this.id = id;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setSubtitle(String subtitle) {
        this.subtitle = subtitle;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setPriority(Priority priority) {
        this.priority = priority;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getSubtitle() {
        return subtitle;
    }

    public String getDescription() {
        return description;
    }

    public String getDate() {
        return date;
    }

    public Priority getPriority() {
        return priority;
    }

    // Enum defining priority levels
    public enum Priority {
        HIGH,
        MEDIUM,
        LOW;
    }
}
